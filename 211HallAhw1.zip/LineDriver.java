
// Austin Hall
// CSCD 211
// 1/ 11/ 19

import java.text.DecimalFormat;
import java.util.Scanner;

public class LineDriver {

	// Main method to display the menu and hold the options
	public static void main(String[] args) {
		Scanner numInput = new Scanner(System.in);
		Line myFirstLine = null;
		Line mySecondLine = null;
		int ui;

		do {
			displayMenu();
			ui = numInput.nextInt();

			switch (ui) {
			case 1:
				myFirstLine = getLine(numInput);
				break;
			case 2:
				mySecondLine = getLine(numInput);
				break;
			case 3:
				// This ensures that there are two lines that can be compared
				if (myFirstLine == null || mySecondLine == null) {
					System.out.println("Please use options 1 and 2 to first create lines, then try again");
				} else {
					if (myFirstLine.equals(mySecondLine)) {
						System.out.println("The two lines are equal");
					} else {
						System.out.println("The two lines are not equal");
					}
				}
				break;
			case 4:
				if (myFirstLine == null || mySecondLine == null) {
					System.out.println("Please use options 1 and 2 to first create lines, then try again");
				} else {
				System.out.println("First " + myFirstLine);
				}
				break;
			case 5:
				if (myFirstLine == null || mySecondLine == null) {
					System.out.println("Please use options 1 and 2 to first create lines, then try again");
			} else {
				System.out.println("Second " + mySecondLine);
			}
				break;
			case 6:
				break;

			}
		} while (ui != 6);

		numInput.close();
	}

	// Method to print the menu options
	public static void displayMenu() {
		System.out.println();
		System.out.println("To select an option, key in a number and then press enter");
		System.out.println("1 - Enter coordinates, width and color for first line");
		System.out.println("2 - Enter coordinates, width and color for second line");
		System.out.println("3 - Compare the two lines");
		System.out.println("4 - Display coordinates, width, length and color for first line");
		System.out.println("5 - Display coordinates, width, length and color for second line");
		System.out.println("6 - Quit");
	}

	// Method used to create a line from user input
	public static Line getLine(Scanner numInput) {
		// Initialization of variables used in method
		int x1;
		int y1;
		int x2;
		int y2;
		int width;
		Line tempLine;
		double length;
		String color;
		// If the line is not valid, this will prompt the user to enter coordinates
		// until they are all valid
		do {
			System.out.println("Enter point x1");
			x1 = numInput.nextInt();
			System.out.println("Enter point y1");
			y1 = numInput.nextInt();
			System.out.println("Enter point x2");
			x2 = numInput.nextInt();
			System.out.println("Enter point y2");
			y2 = numInput.nextInt();
			System.out.println("Enter width");
			width = numInput.nextInt();
			System.out.println("Enter color");
			color = numInput.next();
			if (!Line.validateLine(x1, y1, x2, y2)) {
				System.out.println("Please enter valid coordinates \n");
			}

		} while (!Line.validateLine(x1, y1, x2, y2));

		tempLine = new Line(x1, y1, x2, y2);
		length = tempLine.getLength();

		// This is to create a length with two decimal precision
		length = Double.parseDouble(new DecimalFormat("##.##").format(length));

		return new Line(x1, y1, x2, y2, width, color, length);

	}

}
