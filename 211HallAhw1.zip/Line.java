
// Austin Hall
// CSCD 211
// 1/ 11/ 19

public class Line {
	private int width;
	private String color;
	private Point endPoint1;
	private Point endPoint2;
	private double length;

	// Line DVC
	public Line() {
		this.width = 1;
		this.color = "Black";
		this.endPoint1 = new Point(0, 0);
		this.endPoint2 = new Point(0, 0);

	}

	// Line EVC
	public Line(int x1, int y1, int x2, int y2, int width, String color) {
		this.endPoint1 = new Point(x1, y1);
		this.endPoint2 = new Point(x2, y2);
		this.width = width;
		this.color = color;
	}

	// Line EVC with length parameter
	public Line(int x1, int y1, int x2, int y2, int width, String color, double length) {
		this.endPoint1 = new Point(x1, y1);
		this.endPoint2 = new Point(x2, y2);
		this.width = width;
		this.color = color;
		this.length = length;
	}

	// Line EVC with only point parameters
	public Line(int x1, int y1, int x2, int y2) {
		this(x1, y1, x2, y2, 1, "Black");
	}

	// Getter and setter methods
	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Point getEndPoint1() {
		return endPoint1;
	}

	public void setEndPoint1(Point endPoint1) {
		this.endPoint1 = endPoint1;
	}

	public Point getEndPoint2() {
		return endPoint2;
	}

	public void setEndPoint2(Point endPoint2) {
		this.endPoint2 = endPoint2;
	}

	// Method to test whether the two lines are equal or not, taking into account
	// that the points don't need to be in order
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Line other = (Line) obj;
		if (color == null) {
			if (other.color != null)
				return false;
		} else if (!color.equals(other.color))
			return false;
		if (endPoint1 == null) {
			if (other.endPoint1 != null)
				return false;
		} else if (!endPoint1.equals(other.endPoint1) && !endPoint1.equals(other.endPoint2))
			return false;
		if (endPoint2 == null) {
			if (other.endPoint2 != null)
				return false;
		} else if (!endPoint2.equals(other.endPoint2) && !endPoint2.equals(other.endPoint1))
			return false;
		if (width != other.width)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Line = coordinates: " + endPoint1 + " " + endPoint2 + ", Length: " + length + ", Color: " + color
				+ ", Width: " + width;
	}

	// Method to find length of line based on two endpoints
	public double getLength() {
		double deltaX = this.endPoint1.getX() - this.endPoint2.getX();
		double deltaY = this.endPoint1.getY() - this.endPoint2.getY();

		double length = Math.sqrt(deltaX * deltaY + deltaY * deltaY);
		return length;
	}

	// Method to ensure that the line only exists in the first quadrant
	public static boolean validateLine(int x1, int y1, int x2, int y2) {
		if (x1 < 0 || y1 < 0 || x2 < 0 || y2 < 0) {
			return false;
		}
		return true;
	}

}
