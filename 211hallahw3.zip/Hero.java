// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Scanner;

public abstract class Hero extends DungeonCharacter {

	protected int chanceToBlock;
	protected Integer numberOfTurns;
	protected String type;
	
	public Hero(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange, Integer maxDamageRange,
			int attackChance, int chanceToBlock, Integer numberOfTurns, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance);
		this.chanceToBlock = chanceToBlock;
		this.numberOfTurns = numberOfTurns;
	}
	public Hero() {
		this.name = setCharacterName();
	}

	public int getChanceToBlock() {
		return chanceToBlock;
	}

	public void setChanceToBlock(int chanceToBlock) {
		this.chanceToBlock = chanceToBlock;
	}

	public Integer getNumberOfTurns() {
		return numberOfTurns;
	}

	public void setNumberOfTurns(Integer numberOfTurns) {
		this.numberOfTurns = numberOfTurns;
	}
	
	public String setCharacterName() {
		System.out.println("What would you like your characters name to be?");
		Scanner input = new Scanner(System.in);
		String name = input.next();
		return name;
		
	}
	
	
	
}

