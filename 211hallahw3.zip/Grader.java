// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Random;

public class Grader extends Hero {

	public Grader(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange, Integer maxDamageRange,
			int attackChance, int chanceToBlock, Integer numberOfTurns, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance, chanceToBlock, numberOfTurns,
				type);
		this.hitPoints = 200;
		this.attackSpeed = 4;
		this.attackChance = 90;
		this.minDamageRange = 45;
		this.maxDamageRange = 70;
		this.chanceToBlock = 35;
	}

	public Grader() {
		super.type = "Grader";
		super.hitPoints = 200;
		super.attackSpeed = 4;
		super.attackChance = 90;
		super.minDamageRange = 45;
		super.maxDamageRange = 70;
		super.chanceToBlock = 35;
	}
	
	public static void giveFailingGrade(DungeonCharacter that) {
		Random ran = new Random();
		if (ran.nextInt((100 - 0) + 1) <= 40) {
			int damage = ran.nextInt((100 - 75) + 1) + 75;
			that.hitPoints -= damage;
			System.out.println(that.getName() + " has recieved an F! Their spirits have been crushed and they've lost "
					+ damage + " health points.\n");
			if(that.getHitPoints() > 0) {
				System.out.println(that.getName() + " has " + that.getHitPoints() + " health points left.");
			}
			if(that.getHitPoints() <= 0) {
					System.out.println(that.getName() + " has no health points left!");
			}
		} else {
			System.out.println(that.getName() +" recieved a passing grade! They are unaffected");  
		}
	}

	@Override
	public void attack(Monster that) {
		super.attack(that);
	}
}
