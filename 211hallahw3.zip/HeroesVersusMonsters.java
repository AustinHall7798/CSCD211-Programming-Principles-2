// **I ATTEMPTED BOTH EXTRA CREDIT TASKS**
// Austin Hall
// 2/11/19
// CSCD 211

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class HeroesVersusMonsters {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Hero hero = null;
		Monster monster = createMonster();
		int option;
		boolean tester = true;

		option = displayMenu(hero, monster);

		hero = createHero(option, hero);
		System.out.println("The battle is between " + hero.getName() + " and " + monster.getName() + "!");
		System.out.println("FIGHT!");

		String choice = "";
		int attackOptions = 0;
		do {
			if (monster == null) {
				monster = createMonster();
				hero = createHero(option = displayMenu(hero, monster), hero);
				System.out.println("The battle is between " + hero.getName() + " and " + monster.getName() + "!");
				System.out.println("Fight!");
			}
			if (monster.getHitPoints() <= 0) {
				System.out.println(monster.getName() + " has been slain!");
				System.out.println("\nWould you like to play again? Y/N?");
				choice = input.nextLine();
				if (choice.equals("y") || choice.equals("Y")) {
					hero = null;
					monster = null;
				}
			} else if (hero.getHitPoints() <= 0) {
				System.out.println(hero.getName() + " has been killed!");
				System.out.println("\nWould you like to play again? Y/N?");
				choice = input.nextLine();
				if (choice.equals("y") || choice.equals("Y")) {
					hero = null;
					monster = null;
				}
			} else {
				do {
					try {
						attackOptions = displayFightMenu(hero, monster);
						switch (attackOptions) {
						case 1:
							hero.attack(monster);
							break;
						case 2:
							if (option == 1) {
								Warrior.crushingBlow(monster);
							} else if (option == 2) {
								int supriseOption = Thief.supriseAttack(monster);
								if (supriseOption == 1) {
									hero.setAttackSpeed(hero.getAttackSpeed() * 2);
									hero.attack(monster);
									hero.setAttackSpeed(6);
								} else if (supriseOption == 3) {
									hero.attack(monster);
								}

							} else if (option == 3) {
								hero.hitPoints += Sorceress.heal();
								System.out.println(hero.getName() + " used their special ability and has healed to "
										+ hero.getHitPoints() + " health points!");
							} else if (option == 4) {
								Grader.giveFailingGrade(monster);
							}
							break;
						default:
							System.out.println("Please enter a valid option");
							break;

						}
					} catch (InputMismatchException e) {
						System.out.println("Please enter a valid option");
					}
				} while (!(attackOptions == 1) && !(attackOptions == 2));
				if (monster.getHitPoints() > 0) {
					System.out.println("It's now your opponents turn, press enter to see the results!");
					input.nextLine();
					if (monster.type.equals("Ogre")) {
						if (Ogre.getOutOfMySwampStomp(hero) == false) {
							monster.attack(hero);
						} else {
							Ogre.getOutOfMySwampStomp(hero);
						}
					} else if (monster.type.equals("Gremlin")) {
						if (Gremlin.atePastMidnight() == false) {
							monster.attack(hero);
						} else {
							Gremlin.atePastMidnight();
							monster.setAttackSpeed(monster.getAttackSpeed() + 5);
							monster.attack(hero);
						}
					} else {
						if (Skeleton.rattleMyBones(hero) == true && tester) {
							Skeleton.rattleMyBones(hero);
							tester = false;
						} else {
							monster.attack(hero);
						}

					}
					monster.Heal();

				}
			}

		} while (!choice.equals("N") && !choice.equals("n") && !(attackOptions == 0));

	}

	private static int displayMenu(Hero hero, Monster monster) {
		// Input has a warning that the scanner is never closed, but if I close the
		// scanner here then the System.in for the entire program closes and I can't
		// use it anywhere else
		Scanner input = new Scanner(System.in);

		if (hero == null || monster == null) {
			System.out.println("Welcome to Heroes versus Monsters! Please select a character");

			System.out.println("Character List:");
			System.out.println("1: warrior");
			System.out.println("2: thief");
			System.out.println("3: sorceress");
			System.out.println("4: Grader (New!)");

			int option = 0;
			do {
				try {
					option = input.nextInt();
					if (option == 1) {
						return 1;
					} else if (option == 2) {
						return 2;
					} else if (option == 3) {
						return 3;
					} else if (option == 4) {
						return 4;
					}
					if (option > 4) {
						System.out.println("Values greater than 4 are not an option");
					}
				} catch (InputMismatchException e) {
					System.out.println("Please enter the numeric 1, 2, 3, or 4 as your character option");
					input.next();
				}
			} while (option != 1 || option != 2 || option != 3 || option != 4);

		}

		return 0;
	}

	private static int displayFightMenu(Hero hero, Monster monster) {
		Scanner input = new Scanner(System.in);
		System.out.println("\nChoose your next move!");
		System.out.println("1: ATTACK!");
		System.out.println("2: use special ability");
		int move = input.nextInt();
		return move;

	}

	private static Monster createMonster() {
		Monster monster = null;
		Random randomMonster = new Random();
		int randomGenerateMonster = randomMonster.nextInt((3 - 1) + 1) + 1;
		switch (randomGenerateMonster) {
		case 1:
			monster = new Ogre();
			break;
		case 2:
			monster = new Gremlin();
			break;
		case 3:
			monster = new Skeleton();
			break;
		}
		return monster;
	}

	private static Hero createHero(int option, Hero hero) {
		switch (option) {
		case 1:
			System.out.println("You Chose Warrior!");
			hero = new Warrior();
			break;
		case 2:
			System.out.println("You Chose Thief!");
			hero = new Thief();
			break;
		case 3:
			System.out.println("You Chose Sorceress!");
			hero = new Sorceress();
			break;
		case 4:
			System.out.println("You chose Grader!");
			hero = new Grader();
			break;
		}
		return hero;
	}
}
