
// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Random;

public class Gremlin extends Monster {

	protected String type;

	public Gremlin(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange, Integer maxDamageRange,
			int attackChance, double chanceToHeal, Integer minHealPoints, Integer maxHealPoints, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance, chanceToHeal, minHealPoints,
				maxHealPoints, type);
		this.hitPoints = 70;
		this.attackSpeed = 5;
		this.attackChance = 80;
		this.minDamageRange = 15;
		this.maxDamageRange = 30;
		this.chanceToHeal = 40;
		this.minHealPoints = 20;
		this.maxHealPoints = 40;
	}

	public Gremlin() {
		super.name = "Gizmo";
		super.type = "Gremlin";
		super.hitPoints = 70;
		super.attackSpeed = 5;
		super.attackChance = 80;
		super.minDamageRange = 15;
		super.maxDamageRange = 30;
		super.chanceToHeal = 40;
		super.minHealPoints = 20;
		super.maxHealPoints = 40;
	}

	public static boolean atePastMidnight() {
		Random ran = new Random();
		if (ran.nextInt((100 - 0) + 1) >= 30) {
			return false;
		} else {
			System.out.println("Oh no! Gizmo ate past midnight, now his attack speed has increased!");
			return true;
		}
	}

	@Override
	public void attack(Hero that) {
		super.attack(that);
	}
}
