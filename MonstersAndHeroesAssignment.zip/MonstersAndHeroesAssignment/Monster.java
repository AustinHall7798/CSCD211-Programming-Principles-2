// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Random;

public abstract class Monster extends DungeonCharacter {

	protected double chanceToHeal;
	protected Integer minHealPoints;
	protected Integer maxHealPoints;
	protected String type;

	public Monster(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange, Integer maxDamageRange,
			int attackChance, double chanceToHeal, Integer minHealPoints, Integer maxHealPoints, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance);
		this.chanceToHeal = chanceToHeal;
		this.minHealPoints = minHealPoints;
		this.maxHealPoints = maxHealPoints;
	}

	public Monster() {

	}

	public double getChanceToHeal() {
		return chanceToHeal;
	}

	public void setChanceToHeal(double chanceToHeal) {
		this.chanceToHeal = chanceToHeal;
	}

	public Integer getMinHealPoints() {
		return minHealPoints;
	}

	public void setMinHealPoints(Integer minHealPoints) {
		this.minHealPoints = minHealPoints;
	}

	public Integer getMaxHealPoints() {
		return maxHealPoints;
	}

	public void setMaxHealPoints(Integer maxHealPoints) {
		this.maxHealPoints = maxHealPoints;
	}

	public void Heal() {
		Random ran = new Random();
		if (ran.nextInt((100 - 0) + 1) <= this.chanceToHeal) {
			Integer healPoints = ran.nextInt((this.getMaxHealPoints() - this.getMinHealPoints()) + 1)
					+ this.getMinHealPoints();
			this.hitPoints += healPoints;
			System.out.println(this.getName() + " has healed for " + healPoints + " hitpoints!");
		}
	}

}
