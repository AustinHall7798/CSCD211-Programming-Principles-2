// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Random;

public class Ogre extends Monster {

	protected String type;

	public Ogre(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange, Integer maxDamageRange,
			int attackChance, double chanceToHeal, Integer minHealPoints, Integer maxHealPoints, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance, chanceToHeal, minHealPoints,
				maxHealPoints, type);
		this.name = "Shrek";
		this.hitPoints = 200;
		this.attackSpeed = 2;
		this.attackChance = 60;
		this.minDamageRange = 30;
		this.maxDamageRange = 60;
		this.chanceToHeal = 10;
		this.minHealPoints = 30;
		this.maxHealPoints = 60;
	}

	public Ogre() {
		super.name = "Shrek";
		super.type = "Ogre";
		super.hitPoints = 200;
		super.attackSpeed = 2;
		super.attackChance = 60;
		super.minDamageRange = 30;
		super.maxDamageRange = 60;
		super.chanceToHeal = 10;
		super.minHealPoints = 30;
		super.maxHealPoints = 60;
	}

	public static boolean getOutOfMySwampStomp(DungeonCharacter that) {
		Random ran = new Random();
		if (ran.nextInt((100 - 0) + 1) >= 30) {
			return false;
		} else {
			int damage = ran.nextInt((100 - 60) + 1) + 60;
			that.hitPoints -= damage;
			System.out.println("Shrek's SwampStomp landed and did " + damage + " points of damage! \n");
			if (that.getHitPoints() <= 0) {
				System.out.println(that.getName() + " has no health points left!");
			} else
				System.out.println(that.getName() + " has " + that.getHitPoints() + " health points left.");

			return true;
		}
	}

	@Override
	public void attack(Hero that) {
		super.attack(that);
	}
}
