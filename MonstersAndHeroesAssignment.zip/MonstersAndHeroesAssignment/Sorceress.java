
// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Random;

public class Sorceress extends Hero {

	protected String type;

	public Sorceress(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange,
			Integer maxDamageRange, int attackChance, int chanceToBlock, Integer numberOfTurns, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance, chanceToBlock, numberOfTurns,
				type);
		this.hitPoints = 75;
		this.attackSpeed = 5;
		this.attackChance = 70;
		this.minDamageRange = 25;
		this.maxDamageRange = 45;
		this.chanceToBlock = 30;
	}

	public Sorceress() {
		super.type = "Soreceress";
		super.hitPoints = 75;
		super.attackSpeed = 5;
		super.attackChance = 70;
		super.minDamageRange = 25;
		super.maxDamageRange = 45;
		super.chanceToBlock = 30;
	}

	public static Integer heal() {
		Random ran = new Random();
		Integer healPoints = ran.nextInt((40 - 10) + 1) + 10;
		return healPoints;
	}

	@Override
	public void attack(Monster that) {
		// TODO Auto-generated method stub
		super.attack(that);
	}

}
