
// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Random;

public class Thief extends Hero {

	protected String type;

	public Thief(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange, Integer maxDamageRange,
			int attackChance, int chanceToBlock, Integer numberOfTurns, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance, chanceToBlock, numberOfTurns,
				type);
		this.hitPoints = 75;
		this.attackSpeed = 6;
		this.attackChance = 80;
		this.minDamageRange = 20;
		this.maxDamageRange = 40;
		this.chanceToBlock = 40;
	}

	public Thief() {
		super();
		super.type = "Thief";
		super.hitPoints = 75;
		super.attackSpeed = 6;
		super.attackChance = 80;
		super.minDamageRange = 20;
		super.maxDamageRange = 40;
		super.chanceToBlock = 40;
	}

	public static int supriseAttack(DungeonCharacter that) {
		Random ran = new Random();
		int rannum = ran.nextInt((100 - 0) + 1);
		if (rannum <= 40) {
			System.out.println("Suprise attack successful! The number of attacks you can attempt have doubled.");
			return 1;
		} else if (rannum > 40 && rannum <= 60) {
			System.out.println("You've been caught! The suprise attack was inneffective.");
			return 2;
		} else {
			System.out.println("You weren't quick enough! Just a normal attack landed");
			return 3;
		}
	}

	@Override
	public void attack(Monster that) {
		super.attack(that);
	}
}
