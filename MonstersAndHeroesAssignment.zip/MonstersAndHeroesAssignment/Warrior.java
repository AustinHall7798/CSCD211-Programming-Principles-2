
// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Random;

public class Warrior extends Hero {

	protected String type;

	public Warrior(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange, Integer maxDamageRange,
			int attackChance, int chanceToBlock, Integer numberOfTurns, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance, chanceToBlock, numberOfTurns,
				type);
		this.hitPoints = 125;
		this.attackSpeed = 4;
		this.attackChance = 80;
		this.minDamageRange = 35;
		this.maxDamageRange = 60;
		this.chanceToBlock = 20;
	}

	public Warrior() {
		super.type = "Warrior";
		super.hitPoints = 125;
		super.attackSpeed = 4;
		super.attackChance = 80;
		super.minDamageRange = 35;
		super.maxDamageRange = 60;
		super.chanceToBlock = 20;
	}

	public static void crushingBlow(DungeonCharacter that) {
		Random ran = new Random();
		if (ran.nextInt((100 - 0) + 1) <= 40) {
			int damage = ran.nextInt((175 - 75) + 1) + 75;
			that.hitPoints -= damage;
			System.out.println("The crushing blow has landed and did " + damage + " points of damage. \n");
			if (that.getHitPoints() <= 0) {
				System.out.println(that.getName() + " has no health points left!");
			}
		} else {
			System.out.println("Crushing blow missed");
		}
	}

	@Override
	public void attack(Monster that) {
		super.attack(that);
	}

}
