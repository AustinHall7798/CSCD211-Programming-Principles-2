
// **I ATTEMPTED BOTH EXTRA CREDIT TASKS**
// Austin Hall
// 2/11/19
// CSCD 211

import java.util.Random;

public abstract class DungeonCharacter {

	protected String name;
	protected Integer hitPoints;
	protected Integer attackSpeed;
	protected Integer minDamageRange;
	protected Integer maxDamageRange;
	protected int attackChance;

	public DungeonCharacter(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange,
			Integer maxDamageRange, int attackChance) {
		super();
		this.name = name;
		this.hitPoints = hitPoints;
		this.attackSpeed = attackSpeed;
		this.minDamageRange = minDamageRange;
		this.maxDamageRange = maxDamageRange;
		this.attackChance = attackChance;
	}

	public DungeonCharacter() {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getHitPoints() {
		return hitPoints;
	}

	public void setHitPoints(Integer hitPoints) {
		this.hitPoints = hitPoints;
	}

	public Integer getAttackSpeed() {
		return attackSpeed;
	}

	public void setAttackSpeed(Integer attackSpeed) {
		this.attackSpeed = attackSpeed;
	}

	public Integer getMinDamageRange() {
		return minDamageRange;
	}

	public void setMinDamageRange(Integer minDamageRange) {
		this.minDamageRange = minDamageRange;
	}

	public Integer getMaxDamageRange() {
		return maxDamageRange;
	}

	public void setMaxDamageRange(Integer maxDamageRange) {
		this.maxDamageRange = maxDamageRange;
	}

	public int getAttackChance() {
		return attackChance;
	}

	public void setAttackChance(int attackChance) {
		this.attackChance = attackChance;
	}

	public void attack(Monster that) {
		int attackSpeed = 1;
		if (this.getAttackSpeed() > that.getAttackSpeed()) {
			attackSpeed = this.getAttackSpeed() / that.getAttackSpeed();
		}
		for (int i = 1; i <= attackSpeed; i++) {
			if (i == 1) {
				System.out.println(this.getName() + " is attacking! \n");
			}
			if (i > 1) {
				System.out.println(this.getName() + " strikes again!");
			}
			Random ran = new Random();
			if (ran.nextInt((100 - 0) + 1) > this.attackChance) {
				System.out.println(this.getName() + "'s attack failed!");
			} else {
				int damage = ran.nextInt((this.getMaxDamageRange() - this.getMinDamageRange()) + 1)
						+ this.getMinDamageRange();
				that.hitPoints -= damage;
				if (that.getHitPoints() <= 0) {
					System.out.println(this.getName() + "'s attack landed and did " + damage + " points of damage.");
					System.out.println(that.getName() + " has no health points left!");
				} else {
					System.out.println(this.getName() + "'s attack landed and did " + damage + " points of damage. \n"
							+ that.getName() + " has " + that.getHitPoints() + " health points left. \n");
				}
			}
		}
	}

	public void attack(Hero that) {
		int attackSpeed = 1;
		if (this.getAttackSpeed() > that.getAttackSpeed()) {
			attackSpeed = this.getAttackSpeed() / that.getAttackSpeed();
		}
		for (int i = 1; i <= attackSpeed; i++) {
			if (i == 1) {
				System.out.println(this.getName() + " is attacking! \n");
			}
			if (i > 1) {
				System.out.println(this.getName() + " strikes again!");
			}
			Random ran = new Random();
			if (ran.nextInt((100 - 0) + 1) > this.attackChance) {
				System.out.println(this.getName() + "'s attack failed!");
			} else {
				if (ran.nextInt((100 - 0) + 1) <= that.getChanceToBlock()) {
					System.out.println(that.getName() + " blocked " + this.getName() + "'s attack! No damage taken");
				} else {
					int damage = ran.nextInt((this.getMaxDamageRange() - this.getMinDamageRange()) + 1)
							+ this.getMinDamageRange();
					that.hitPoints -= damage;
					if (that.getHitPoints() <= 0) {
						System.out
								.println(this.getName() + "'s attack landed and did " + damage + " points of damage.");
						System.out.println(that.getName() + " has no health points left!");
					} else {
						System.out
								.println(this.getName() + "'s attack landed and did " + damage + " points of damage. \n"
										+ that.getName() + " has " + that.getHitPoints() + " health points left. \n");
					}
				}
			}
		}
	}
}
