
// Austin Hall
// 2/11/19
// CSCD 211
import java.util.Random;

public class Skeleton extends Monster {

	protected String type;

	public Skeleton(String name, Integer hitPoints, Integer attackSpeed, Integer minDamageRange, Integer maxDamageRange,
			int attackChance, double chanceToHeal, Integer minHealPoints, Integer maxHealPoints, String type) {
		super(name, hitPoints, attackSpeed, minDamageRange, maxDamageRange, attackChance, chanceToHeal, minHealPoints,
				maxHealPoints, type);
		this.hitPoints = 100;
		this.attackSpeed = 3;
		this.attackChance = 80;
		this.minDamageRange = 30;
		this.maxDamageRange = 50;
		this.chanceToHeal = 30;
		this.minHealPoints = 30;
		this.maxHealPoints = 50;
	}

	public Skeleton() {
		super.name = "Jack Skellington";
		super.type = "Skeleton";
		super.hitPoints = 100;
		super.attackSpeed = 3;
		super.attackChance = 80;
		super.minDamageRange = 30;
		super.maxDamageRange = 50;
		super.chanceToHeal = 30;
		super.minHealPoints = 30;
		super.maxHealPoints = 50;
	}

	public static boolean rattleMyBones(DungeonCharacter that) {
		Random ran = new Random();
		if (ran.nextInt((100 - 0) + 1) >= 30) {
			return false;
		} else if (that.getAttackChance() == 55) {
			return false;

		} else {
			that.setAttackChance(55);
			System.out.println("Jack Skellingtons fearsome appearance has frightened " + that.getName()
					+ "\n so much that they can no longer attack with confidence! \n" + that.getName()
					+ " only has a little over" + " 50% of a chance to attack. \n");
			return true;
		}
	}

	@Override
	public void attack(Hero that) {
		super.attack(that);
	}
}
