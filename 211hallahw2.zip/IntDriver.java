// Austin Hall
// 1/30/19
// CSCD 211

// **I wrote my own methods for conversion and the program can compute with negative numbers**

import java.util.Scanner;

public class IntDriver extends LongInteger {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		// Initialization of variables
		LongInteger num1 = null;
		LongInteger num2 = null;

		int mode = 10;
		String operation = "";
		String option;

		// Displays the menu
		option = displayMenu(mode, input, num1, operation, num2);

		// registers if the user quits the program or changes the mode to user input
		// Also changes the operation to the users input
		while (!option.equals("Q") && !option.equals("q")) {
			option = option.toUpperCase();
			if (option.equals("DCM")) {
				mode = 10;
			} else if (option.equals("BIN")) {
				mode = 2;
			} else if (option.equals("OCT")) {
				mode = 8;
			} else if (option.equals("HEX")) {
				mode = 16;
			} else if (option.equals("+") || option.equals("-") || option.equals("*") || option.equals("/")) {
				operation = option;
			} else if (option.equals("=")) {
				// does the calculation if both numbers are entered and the user
				// doesn't attempt to divide by 0
				if (num1 != null && num2 != null) {
					if (!(operation.equals("/") && num2.getDecimal() == 0)) {
						num1.calcValue(operation, num2);
						num1 = num2;
						num2 = null;
						operation = "";
					} else {
						System.out.println("\tOperation Undefined.");
					}
				}
			} else {
				// if the user doesn't input any predefined options, the program will
				// check to see if the input is valid with the defined base,
				// then creates a longInteger object
				if (LongInteger.isValid(option, mode) == true) {
					if (operation.equals("") || num1 == null) {
						if (mode == 2) {
							num1 = new BinaryInteger(option);
						} else if (mode == 8) {
							num1 = new OctalInteger(option);
						} else if (mode == 16) {
							num1 = new HexInteger(option);
						} else if (mode == 10) {
							num1 = new DecimalInteger(option);
						}
					} else {
						if (mode == 2) {
							num2 = new BinaryInteger(option);
						} else if (mode == 8) {
							num2 = new OctalInteger(option);
						} else if (mode == 16) {
							num2 = new HexInteger(option);
						} else if (mode == 10) {
							num2 = new DecimalInteger(option);
						}
					}
				} else {
					System.out.println("* " + option + " is not a valid input for base " + mode + " numbers* ");
				}
			}
			option = displayMenu(mode, input, num1, operation, num2);
		}
		input.close();
	}

	// Method to display the options, number, and mode. Returns the user input
	private static String displayMenu(int mode, Scanner input, LongInteger num1, String operation, LongInteger num2) {

		System.out.println();
		if (mode == 2) {
			System.out.println("Binary Mode");
		}
		if (mode == 8) {
			System.out.println("Octal Mode");
		}
		if (mode == 10) {
			System.out.println("Decimal Mode");
		}
		if (mode == 16) {
			System.out.println("Hexadecimal Mode");
		}

		if (num1 != null) {
			System.out.print(num1.toString() + " ");
		}
		if (operation != "") {
			System.out.print(operation + " ");
		}
		if (num2 != null) {
			System.out.print(num2.toString());
		}

		System.out.println();
		System.out.println();
		System.out.println("BIN- Binary          +");
		System.out.println("OCT- Octal           -");
		System.out.println("DCM- Decimal         *");
		System.out.println("HEX- Hexadecinal     /");
		System.out.println("Q- Quit              =");
		System.out.println("Option or value -->");

		String stringMode = input.next();
		return stringMode;
	}

}
