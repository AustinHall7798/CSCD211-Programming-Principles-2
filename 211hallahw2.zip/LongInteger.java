
// Austin Hall
// 1/30/19
// CSCD 211
// **I wrote my own methods for conversion and the program can compute with negative numbers**
public class LongInteger {

	private long value;

	protected LongInteger() {
		this.value = 0;
	}

	public void setDecimal(long value) {
		this.value = value;
	}

	public Long getDecimal() {
		return value;
	}
	

	// Method to conduct the arithmetic based on the users chosen operation
	public void calcValue(String operation, LongInteger that) {
		long answer = 0;

		if (operation.equals("+")) {
			answer = this.value + that.value;
		} else if (operation.equals("-")) {
			answer = this.value - that.value;
		} else if (operation.equals("*")) {
			answer = this.value * that.value;
		} else if (operation.equals("/")) {
			answer = this.value / that.value;
		}
		
		that.setDecimal(answer);
	}

	public static String convertFromLong(Long input, int base) {
		// create and initialize all the arrays and variables necessary
		String[] tempArray = new String[50];
		long num = input;
		long[] numHolder = new long[50];
		int index = 0;
		long holder = 0;
		String finalStringOutput = "";

		if (input < 0) {
			num *= -1;
		}

		// converts the decimal based number into the number of specified base
		for (long i = num; i != 0; index++) {
			holder = i % base;
			i /= base;
			numHolder[index] = holder;
		}
		// creates and populates an array of strings from the long in the original array
		for (int i = 0; i < numHolder.length; i++) {
			tempArray[i] = Long.toString(numHolder[i]);

		}
		// converts decimal numbers into hex letters
		for (int i = 0; i < index; i++) {
			if (tempArray[i].equals("10")) {
				tempArray[i] = "A";
			} else if (tempArray[i].equals("11")) {
				tempArray[i] = "B";
			} else if (tempArray[i].equals("12")) {
				tempArray[i] = "C";
			} else if (tempArray[i].equals("13")) {
				tempArray[i] = "D";
			} else if (tempArray[i].equals("14")) {
				tempArray[i] = "E";
			} else if (tempArray[i].equals("15")) {
				tempArray[i] = "F";
			}
		}

		String[] finalArray = new String[index];

		// the array was created with the numbers in the reverse order in the array, so
		// this flips them,
		// as well as condensing the length of the array to a necessary length
		for (int i = 0, j = index - 1; i < index; i++, j--) {
			finalArray[j] = tempArray[i];
		}

		// this takes the strings out of the array and puts them into one string
		for (int i = 0; i < finalArray.length; i++) {
			finalStringOutput += finalArray[i];
		}

		// if the long was a negative, this will erase the previously initialized
		// finalStringOutput
		// and place a "-" in front, before filling in numbers
		if (input < 0) {
			finalStringOutput = "-";
			for (int i = 0; i < finalArray.length; i++) {
				finalStringOutput += finalArray[i];
			}
		}

		return finalStringOutput;
	}

	// method that takes a string input and converts the number to a long
	public static long convertToLong(String input, int base) {
		// if the passed in number is a negative, this removes the negative sign and
		// saves the
		// sign value for later use
		int sign = 1;
		if (input.charAt(0) == '-') {
			sign = -1;
			input = input.substring(1);

			input = input.trim();
		}
		// creates an array of strings, placing the individual digits in their own index
		String[] str = input.split("");
		// This will look in each index and change hex letters into their decimal
		// equivalent
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("A") || str[i].equals("a")) {
				str[i] = "10";
			} else if (str[i].equals("B") || str[i].equals("b")) {
				str[i] = "11";
			} else if (str[i].equals("C") || str[i].equals("c")) {
				str[i] = "12";
			} else if (str[i].equals("D") || str[i].equals("d")) {
				str[i] = "13";
			} else if (str[i].equals("E") || str[i].equals("e")) {
				str[i] = "14";
			} else if (str[i].equals("F") || str[i].equals("f")) {
				str[i] = "15";
			}
		}

		// this takes the number in each index, converts it into a long, multiplies it
		// by the base
		// to the power of its position from 0, then adds them into the final number
		long finalNumber = 0;
		for (int i = 0; i < str.length; i++) {
			finalNumber += Integer.parseInt(str[i]) * Math.pow(base, str.length - i - 1);
		}
		return finalNumber * sign;

	}

	// Very long and convoluted method to check that the input with a given base is
	// acceptable.
	// The method length is twice as long as original to ensure the negative sign is
	// in the front
	// of the number, otherwise the program would break if it were elsewhere
	public static boolean isValid(String option, int mode) {
		String[] optionArray = option.split("");
		if (mode == 2) {
			if (optionArray[0].equals("-")) {
				for (int i = 1; i < optionArray.length; i++) {
					if (!optionArray[i].equals("1") && !optionArray[i].equals("0")) {
						return false;
					}
				}
			} else {
				for (int i = 0; i < optionArray.length; i++) {
					if (!optionArray[i].equals("1") && !optionArray[i].equals("0")) {
						return false;
					}
				}
			}
		} else if (mode == 8) {
			if (optionArray[0].equals("-")) {
				for (int i = 1; i < optionArray.length; i++) {
					if (!optionArray[i].equals("0") && !optionArray[i].equals("1") && !optionArray[i].equals("2")
							&& !optionArray[i].equals("3") && !optionArray[i].equals("4") && !optionArray[i].equals("5")
							&& !optionArray[i].equals("6") && !optionArray[i].equals("7")) {
						return false;
					}
				}
			} else {
				for (int i = 0; i < optionArray.length; i++) {
					if (!optionArray[i].equals("0") && !optionArray[i].equals("1") && !optionArray[i].equals("2")
							&& !optionArray[i].equals("3") && !optionArray[i].equals("4") && !optionArray[i].equals("5")
							&& !optionArray[i].equals("6") && !optionArray[i].equals("7")) {
						return false;
					}
				}
			}
		} else if (mode == 10) {
			if (optionArray[0].equals("-")) {

				for (int i = 1; i < optionArray.length; i++) {
					if (!optionArray[i].equals("0") && !optionArray[i].equals("1") && !optionArray[i].equals("2")
							&& !optionArray[i].equals("3") && !optionArray[i].equals("4") && !optionArray[i].equals("5")
							&& !optionArray[i].equals("6") && !optionArray[i].equals("7") && !optionArray[i].equals("8")
							&& !optionArray[i].equals("9")) {
						return false;
					}
				}
			} else {
				for (int i = 0; i < optionArray.length; i++) {
					if (!optionArray[i].equals("0") && !optionArray[i].equals("1") && !optionArray[i].equals("2")
							&& !optionArray[i].equals("3") && !optionArray[i].equals("4") && !optionArray[i].equals("5")
							&& !optionArray[i].equals("6") && !optionArray[i].equals("7") && !optionArray[i].equals("8")
							&& !optionArray[i].equals("9")) {
						return false;
					}
				}
			}
		} else if (mode == 16) {
			if (optionArray[0].equals("-")) {

				for (int i = 1; i < optionArray.length; i++) {
					if (!optionArray[i].equals("0") && !optionArray[i].equals("1") && !optionArray[i].equals("2")
							&& !optionArray[i].equals("3") && !optionArray[i].equals("4") && !optionArray[i].equals("5")
							&& !optionArray[i].equals("6") && !optionArray[i].equals("7") && !optionArray[i].equals("8")
							&& !optionArray[i].equals("9") && !optionArray[i].equals("A") && !optionArray[i].equals("B")
							&& !optionArray[i].equals("C") && !optionArray[i].equals("D") && !optionArray[i].equals("E")
							&& !optionArray[i].equals("F")) {
						return false;
					}
				}
			} else {
				for (int i = 0; i < optionArray.length; i++) {
					if (!optionArray[i].equals("0") && !optionArray[i].equals("1") && !optionArray[i].equals("2")
							&& !optionArray[i].equals("3") && !optionArray[i].equals("4") && !optionArray[i].equals("5")
							&& !optionArray[i].equals("6") && !optionArray[i].equals("7") && !optionArray[i].equals("8")
							&& !optionArray[i].equals("9") && !optionArray[i].equals("A") && !optionArray[i].equals("B")
							&& !optionArray[i].equals("C") && !optionArray[i].equals("D") && !optionArray[i].equals("E")
							&& !optionArray[i].equals("F")) {
						return false;
					}
				}
			}
		}
		return true;
	}
}
