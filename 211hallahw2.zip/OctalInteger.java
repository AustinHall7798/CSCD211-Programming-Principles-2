
// Austin Hall
// 1/30/19
// CSCD 211
public class OctalInteger extends LongInteger {

	// creates an octal integer object based on the user input, converts the string to long
	public OctalInteger(String value) {
		long decVal;
		decVal = LongInteger.convertToLong(value, 8);
		this.setDecimal(decVal);
	}

	// returns the result of converting the long into a string with base 8
	public String toString() {
		String result;
		result = LongInteger.convertFromLong(this.getDecimal(), 8);
		return result + " (Octal)";

	}
}
