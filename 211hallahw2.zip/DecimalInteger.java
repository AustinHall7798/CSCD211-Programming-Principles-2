
// Austin Hall
// 1/30/19
// CSCD 211
public class DecimalInteger extends LongInteger{

	// creates a decimal integer object based on the user input, converts the string to long
	public DecimalInteger(String value) {
		long decVal;
		decVal = LongInteger.convertToLong(value, 10);
		this.setDecimal(decVal);
	}

	// returns the result of converting the long into a string with base 10
	public String toString() {
		String result;
		result = LongInteger.convertFromLong(this.getDecimal(), 10);
		return result + " (Decimal)";

	}
}
