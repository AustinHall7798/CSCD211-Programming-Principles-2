
// Austin Hall
// 1/30/19
// CSCD 211
public class BinaryInteger extends LongInteger {

	// creates a binary integer object based on the user input, converts the string to long
	public BinaryInteger(String value) {
		long decVal;
		decVal = LongInteger.convertToLong(value, 2);
		this.setDecimal(decVal);
	}

	// returns the result of converting the long into a string with base 2
	public String toString() {
		String result = "";
		result = LongInteger.convertFromLong(this.getDecimal(), 2);
		return result + " (Binary)";

	}

}
