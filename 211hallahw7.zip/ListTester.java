// Austin Hall
// 3/12/19
// CSCD 211

// Extra credit attempted
// This program creates a doubly Linked list of user specified size,
// and gives several options with what to do with that list

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class ListTester {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int option = 0;
		LinkedList myList = new LinkedList();
		LinkedList subList = new LinkedList();

		option = displayMenu(input);

		while (option != 9) {
			try {
				switch (option) {

				case 1:
					System.out.println("Please enter the length of the list");
					int number = input.nextInt();
					if (number > 0) {
						myList = LinkedList.createList(number);
					} else {
						System.out.println("Please enter a valid length");
					}
					break;
				case 2:
					if (!myList.isEmpty()) {
						myList.sortList();
					} else {
						System.out.println("Cannot sort a list that isn't there\n");
					}
					break;
				case 3:
					if (!myList.isEmpty())
						System.out.println(myList);
					else
						System.out.println("There is no list created \n");
					break;
				case 4:
					if (!myList.isEmpty()) {
						myList.reverseList();
					} else
						System.out.println("There is no list created \n");
					break;
				case 5:
					if (!myList.isEmpty()) {
						subList = myList.createEvenList();
						System.out.println(subList);
					} else {
						System.out.println("There is no list created \n");
					}
					break;
				case 6:
					if (!myList.isEmpty()) {
						System.out.println("Please enter the value of n");
						int num = input.nextInt();
						myList.findNthItem(num);
					} else {
						System.out.println("There is no list created");
					}
					break;
				case 7:
					if (!myList.isEmpty()) {
						System.out.println("Enter the value you'd like to remove");
						Object removeNode = input.nextInt();
						myList.removeNode(removeNode);
					} else {
						System.out.println("The list is empty");
					}
					break;
				case 8:
					myList.deleteList();
					System.out.println("Current linked list has been deleted");
					break;
				}
			} catch (InputMismatchException e) {
				System.out.println("Please select a task and try again with a valid integer");
				input.next();
			}
			option = displayMenu(input);
		}
		input.close();
	}

	private static int displayMenu(Scanner input) {
		System.out.println();
		System.out.println("Please select an option from the list");
		System.out.println("1: Create a new linked list");
		System.out.println("2: Sort the current linked list");
		System.out.println("3: Print the list");
		System.out.println("4: Print the list in reverse order");
		System.out.println("5: Create a sub list of only even numbers");
		System.out.println("6: Print the Nth item in the list");
		System.out.println("7: Delete a specified number from the list");
		System.out.println("8: Delete the contents of the current list");
		System.out.println("9: Quit the program");

		try {
			int option = input.nextInt();
			return option;
		} catch (InputMismatchException e) {
			System.out.println("Please enter a valid number");
			input.next();
		}
		return 0;

	}

	public static int randomGenerator() {
		Random ran = new Random();
		int rannum = ran.nextInt(100);
		return rannum;
	}
}
