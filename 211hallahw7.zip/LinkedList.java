// Austin Hall
// 3/12/19
// CSCD 211

// This is a doubly linked list

public class LinkedList {

	private Node head;
	private Node tail;
	private int size;

	public LinkedList() {
		head = null;
		tail = null;
		size = 0;
	}

	public boolean isEmpty() {
		return size == 0;
	}

	private class Node {
		private Object item;
		private Node next;
		private Node prev;

		private Node(Object newItem) {
			this.item = newItem;
			this.next = null;
			this.prev = null;
		}

		public Object getItem() {
			return this.item;
		}

		public Node getNext() {
			return this.next;
		}

		public void setNext(Node nextNode) {
			this.next = nextNode;
		}

		public Node getPrev() {
			return this.prev;
		}

		public void setPrev(Node prevNode) {
			this.prev = prevNode;
		}

		public String toString() {
			return this.getItem().toString();
		}

	}

	// Creates a list of user specified size, filled with random Integers
	protected static LinkedList createList(int length) {
		LinkedList myList = new LinkedList();

		if (length != 0) {
			for (int i = 0; i < length; i++) {
				myList.addNode(ListTester.randomGenerator());
			}
			return myList;
		}
		return null;

	}

	// Adds a node to the list, used only to create the list
	private void addNode(Object newItem) {
		Node newNode = new Node(newItem);
		Node curr;
		if (isEmpty()) {
			head = newNode;
			head.prev = null;
			tail = head;
		} else {
			for (curr = head; curr.getNext() != null; curr = curr.getNext()) {
				if (curr.next.next == null) {
					curr.next.setPrev(curr);
				}
			}
			curr.setNext(newNode);
			tail = curr.next;
			tail.prev = curr;
		}
		size++;
	}

	// Prints the list beginning with the tail to the head
	public void reverseList() {
		Node position = tail;

		while (position != null) {
			System.out.println(position);
			position = position.prev;
		}
	}

	// Sorts the list from smallest to largest
	public void sortList() {
		Node position;
		Node start;
		Node smallest = head;

		if (size > 0) {
			for (position = head; position != null; position = position.next) {
				smallest = position;
				for (start = position.next; start != null; start = start.next) {
					if ((Integer) start.item < (Integer) smallest.item) {
						smallest = start;
					}
				}
				Object temp = position.item;
				position.item = smallest.item;
				smallest.item = temp;
			}

		}

	}

	// Prints out a subList with data at user specified points
	public void findNthItem(int n) {
		Node curr = head;
		int j;
		int iterations = size / n;
		for (int i = 0; i < iterations; i++) {
			if (curr == head) {
				for (j = 1; j < n; j++) {
					curr = curr.getNext();
				}
			} else {
				for (j = 0; j < n; j++) {
					if (curr.getNext() != null)
						curr = curr.getNext();
				}
			}
			System.out.println(curr);
		}
	}

	// Removes every node with user specified value
	// This is a long method to ensure that each value is deleted
	// and it doesn't cause problems in the program
	public void removeNode(Object value) {
		int numOfDeletes = 0;
		int tempSize = size;
		Node curr = head;
		Node prev;
		// If the list size is 1 then it just deletes the whole list
		if (size == 1 && curr.item.equals(value)) {
			deleteList();
			numOfDeletes++;

		} else {
			for (int i = 0; i < tempSize; i++) {
				// special case
				if (head.item.equals(value)) {
					curr = head.getNext();
					head = curr;
					numOfDeletes++;
					size--;
				}
				if (curr.getNext() != null) {
					if (curr.item.equals(value)) {
						prev = curr.getPrev();
						while (!curr.getNext().equals(null) && curr.getNext().equals(value)) {
							curr = curr.getNext();
							size--;
						}
						prev.setNext(curr.getNext().getNext());
						size--;
						numOfDeletes++;
					}
					curr = curr.getNext();
				}
				// special case
				if (tail.item.equals(value)) {
					tail = tail.prev;
					tail.setNext(null);
					numOfDeletes++;
					size--;
				}
			}
		}
		System.out.println(numOfDeletes + " items deleted from list");

	}

	// Creates a subList with only even Integers
	public LinkedList createEvenList() {
		Node position;
		LinkedList newList = new LinkedList();

		for (position = head; position != null; position = position.next) {
			if ((Integer) position.item % 2 == 0) {
				newList.addNode(position);
			}
		}
		return newList;
	}

	public String toString() {
		String result = "";
		for (Node curr = this.head; curr != null; curr = curr.getNext()) {
			result = result + curr.getItem().toString() + "\n";

		}
		return result;
	}

	public void deleteList() {
		this.head = null;
		size = 0;
	}

}
