
// Austin Hall
// CSCD 211
// 2/27/19

public class MazeTester {

	static int[][] grid = { { 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1 }, 
							{ 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1 },
							{ 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0 }, 
							{ 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1 },
							{ 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1 }, 
							{ 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1 },
							{ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, 
							{ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 } };

	public static void main(String[] args) {
		boolean solveable = mazeRunner(0, 0);

		if (solveable) {
			System.out.println("The Program found a path! \nThis is what it looks like");
		} else {
			System.out.println("There is no possible path in this maze.");
			System.out.println("This is what was tried");
		}
		for (int i = 0; i < grid.length; i++) {
			for (int k = 0; k < grid[i].length; k++) {
				System.out.print(grid[i][k]);
			}
			System.out.println();
		}

	}

	private static boolean mazeRunner(int x, int y) {
		
		// Boolean variable that is only true if a correct path has been found
		boolean isPath = false;
		
		// Only runs if the index is within the array
		if (isValid(x, y)) {
			// Marks the room as visited
			grid[x][y] = 3;

			// If the program has made it to the end, it will unwind the recursion 
			if (x == grid.length - 1 && y == grid[0].length - 1) {
				isPath = true;
			} else {
				// While the program hasn't reached the end, it will systematically check each room
				// and backtrack to previous method calls if it reaches a dead end
				if (!isPath)
					isPath = mazeRunner(x - 1, y);
				if (!isPath)
					isPath = mazeRunner(x, y + 1);
				if (!isPath)
					isPath = mazeRunner(x, y - 1);
				if (!isPath)
					isPath = mazeRunner(x + 1, y);
			}
			if (isPath) {
				// Will mark each room as the path if the program reaches the end of the maze
				// and the unwinding process begins
				grid[x][y] = 7;
			}
		}
		return isPath;

	}

	private static boolean isValid(int x, int y) {
		// Ensures that the index to be checked is in the array
		if (x >= 0 && x < grid.length && y >= 0 && y < grid[0].length)
			if (grid[x][y] == 1)
				return true;
		return false;
	}
}
