
// Austin Hall
// CSCD 211
// 2/20/19
import java.util.Scanner;

public class SubStringTester {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String option;
		System.out.println("Enter the word to be iterated,");
		System.out.println("then press enter");
		do {

			option = input.next();
			if (!option.equals("q") && !option.equals("Q")) {
				subStringGenerator(option);
				System.out.println("Enter another word, or press Q to quit");
			}
		} while (!option.equals("q") && !option.equals("Q"));
		input.close();

	}

	private static String subStringGenerator(String string) {
		return subStringGenerator(string, string);

	}

	private static String subStringGenerator(String string, String placeHolderString) {

		if (placeHolderString.length() == 0) {
			return string;
		}

		if (string.length() != 0) {
			System.out.println(string);
			return subStringGenerator(string.substring(0, string.length() - 1), placeHolderString);

		} else {

			string = placeHolderString.substring(1);

		}
		return subStringGenerator(string);

	}
}
